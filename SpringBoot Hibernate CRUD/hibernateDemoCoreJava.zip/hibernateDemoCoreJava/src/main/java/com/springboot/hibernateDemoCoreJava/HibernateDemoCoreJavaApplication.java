package com.springboot.hibernateDemoCoreJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateDemoCoreJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateDemoCoreJavaApplication.class, args);
	}

}
